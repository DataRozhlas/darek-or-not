const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({});
const dynamo = DynamoDBDocumentClient.from(client);

exports.handler = async (event, context) => {
    let body;
    let statusCode = 200;

    try {
        console.log('Received event:', JSON.stringify(event)); // Debug logging

        // Handle both direct JSON and stringified body
        let requestJSON = typeof event.body === 'string' ? JSON.parse(event.body) : event;

        const timestamp = Date.now().toString();
        const randomNum = Math.floor(Math.random() * 10000).toString();
        const uid = timestamp + randomNum;

        await dynamo.send(
            new PutItemCommand({
                TableName: "cukrovi-or-not",
                Item: {
                    uid: { N: uid },
                    appID: { S: requestJSON.appID },
                    winnerID: { N: requestJSON.winnerID.toString() },
                    url: { S: requestJSON.url },
                    ref: { S: requestJSON.ref },
                    age: { S: requestJSON.age },
                    sex: { S: requestJSON.sex },
                    sessionID: { S: requestJSON.sid },
                    loserID: { N: requestJSON.loserID.toString() },
                    draw: { BOOL: requestJSON.draw },
                    ip: { S: event.headers?.["x-forwarded-for"] || 'unknown' }
                }
            })
        );

        body = { message: "Success" };
    } catch (err) {
        console.error('Error:', err); // Debug logging
        statusCode = 400;
        body = { error: err.message };
    }

    return {
        statusCode,
        body: JSON.stringify(body)
    };
};
